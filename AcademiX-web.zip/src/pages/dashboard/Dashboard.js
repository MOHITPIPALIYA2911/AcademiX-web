import React from 'react';

const Dashboard = () => {
  return (
    <>asda</>
  );
};

export default Dashboard;
